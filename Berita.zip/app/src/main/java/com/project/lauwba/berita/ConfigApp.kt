package com.project.lauwba.berita

object ConfigApp {
    private val HOST = "http://192.168.56.1/WebBerita/"
    val URL_BERITA_ = HOST + "index.php/json"
    val URL_BERITA_DETAIL = HOST + "index.php/json/get_berita/"
    val URL_GAMBAR = HOST + "assets/gambar/"
    val DATA_ARRAY = "data"
    val ID_BERITA = "id_berita"
}